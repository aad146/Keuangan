const form = document.getElementById('absenForm');
const namaSiswa = document.getElementById('namaSiswa');
const statusAbsen = document.getElementById('statusAbsen');
const rekapTable = document.getElementById('rekapTable').querySelector('tbody');

let dataAbsensi = {};

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const nama = namaSiswa.value;
  const status = statusAbsen.value;

  if (!dataAbsensi[nama]) {
    dataAbsensi[nama] = { Hadir: 0, Sakit: 0, Izin: 0, Alfa: 0 };
  }

  dataAbsensi[nama][status]++;
  updateTable();
  form.reset();
});

function updateTable() {
  rekapTable.innerHTML = '';
  for (const nama in dataAbsensi) {
    const { Hadir, Sakit, Izin, Alfa } = dataAbsensi[nama];
    rekapTable.innerHTML += `
      <tr>
        <td>${nama}</td>
        <td>${Hadir}</td>
        <td>${Sakit}</td>
        <td>${Izin}</td>
        <td>${Alfa}</td>
      </tr>
    `;
  }
}